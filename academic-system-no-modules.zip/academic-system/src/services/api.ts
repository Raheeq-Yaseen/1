import axios from 'axios';

// Base API URL
const API_URL = '/api';

// Study System Services
export const fetchLearningMaterials = async () => {
  try {
    const response = await axios.get(`${API_URL}/materials`);
    return response.data;
  } catch (error) {
    console.error('שגיאה בטעינת חומרי לימוד:', error);
    throw error;
  }
};

export const searchLearningMaterials = async (query) => {
  try {
    const response = await axios.get(`${API_URL}/materials/search`, { params: { q: query } });
    return response.data;
  } catch (error) {
    console.error('שגיאה בחיפוש חומרי לימוד:', error);
    throw error;
  }
};

// Summary Library Services
export const fetchSummaries = async () => {
  try {
    const response = await axios.get(`${API_URL}/summaries`);
    return response.data;
  } catch (error) {
    console.error('שגיאה בטעינת סיכומים:', error);
    throw error;
  }
};

export const uploadSummary = async (summaryData) => {
  try {
    const response = await axios.post(`${API_URL}/summaries`, summaryData);
    return response.data;
  } catch (error) {
    console.error('שגיאה בהעלאת סיכום:', error);
    throw error;
  }
};

export const rateSummary = async (summaryId, rating) => {
  try {
    const response = await axios.post(`${API_URL}/summaries/${summaryId}/rate`, { rating });
    return response.data;
  } catch (error) {
    console.error('שגיאה בדירוג סיכום:', error);
    throw error;
  }
};

// Task Manager Services
export const fetchTasks = async () => {
  try {
    const response = await axios.get(`${API_URL}/tasks`);
    return response.data;
  } catch (error) {
    console.error('שגיאה בטעינת משימות:', error);
    throw error;
  }
};

export const createTask = async (taskData) => {
  try {
    const response = await axios.post(`${API_URL}/tasks`, taskData);
    return response.data;
  } catch (error) {
    console.error('שגיאה ביצירת משימה:', error);
    throw error;
  }
};

export const updateTaskStatus = async (taskId, status) => {
  try {
    const response = await axios.patch(`${API_URL}/tasks/${taskId}`, { status });
    return response.data;
  } catch (error) {
    console.error('שגיאה בעדכון סטטוס משימה:', error);
    throw error;
  }
};

// Writing Tool Services
export const fetchTemplates = async () => {
  try {
    const response = await axios.get(`${API_URL}/templates`);
    return response.data;
  } catch (error) {
    console.error('שגיאה בטעינת תבניות:', error);
    throw error;
  }
};

export const saveDocument = async (documentData) => {
  try {
    const response = await axios.post(`${API_URL}/documents`, documentData);
    return response.data;
  } catch (error) {
    console.error('שגיאה בשמירת מסמך:', error);
    throw error;
  }
};

export const checkDocument = async (documentData) => {
  try {
    const response = await axios.post(`${API_URL}/documents/check`, documentData);
    return response.data;
  } catch (error) {
    console.error('שגיאה בבדיקת מסמך:', error);
    throw error;
  }
};

// Social System Services
export const fetchUsers = async () => {
  try {
    const response = await axios.get(`${API_URL}/users`);
    return response.data;
  } catch (error) {
    console.error('שגיאה בטעינת משתמשים:', error);
    throw error;
  }
};

export const searchUsers = async (query) => {
  try {
    const response = await axios.get(`${API_URL}/users/search`, { params: { q: query } });
    return response.data;
  } catch (error) {
    console.error('שגיאה בחיפוש משתמשים:', error);
    throw error;
  }
};

export const sendMessage = async (userId, message) => {
  try {
    const response = await axios.post(`${API_URL}/messages`, { userId, message });
    return response.data;
  } catch (error) {
    console.error('שגיאה בשליחת הודעה:', error);
    throw error;
  }
};

export const addContact = async (userId) => {
  try {
    const response = await axios.post(`${API_URL}/contacts`, { userId });
    return response.data;
  } catch (error) {
    console.error('שגיאה בהוספת איש קשר:', error);
    throw error;
  }
};
