import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Textarea } from '../../components/ui/textarea';
import { Input } from '../../components/ui/input';
import { Save, FileText, Check, AlertCircle } from 'lucide-react';

interface Template {
  id: string;
  name: string;
  type: string;
  sections: {
    title: string;
    description: string;
    required: boolean;
  }[];
}

const WritingTool: React.FC = () => {
  const [activeTab, setActiveTab] = useState('editor');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [templates, setTemplates] = useState<Template[]>([]);
  const [content, setContent] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call to fetch templates
    const fetchTemplates = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        const demoTemplates: Template[] = [
          {
            id: '1',
            name: 'עבודת מחקר אקדמית',
            type: 'research',
            sections: [
              {
                title: 'תקציר',
                description: 'סיכום קצר של העבודה בכ-250 מילים',
                required: true
              },
              {
                title: 'מבוא',
                description: 'הצגת הנושא, שאלת המחקר והרקע לעבודה',
                required: true
              },
              {
                title: 'סקירת ספרות',
                description: 'סקירה של מחקרים קודמים בתחום',
                required: true
              },
              {
                title: 'מתודולוגיה',
                description: 'תיאור שיטת המחקר, כלים ומשתתפים',
                required: true
              },
              {
                title: 'ממצאים',
                description: 'הצגת תוצאות המחקר',
                required: true
              },
              {
                title: 'דיון',
                description: 'ניתוח הממצאים והשלכותיהם',
                required: true
              },
              {
                title: 'מסקנות',
                description: 'סיכום המסקנות העיקריות מהמחקר',
                required: true
              },
              {
                title: 'ביבליוגרפיה',
                description: 'רשימת מקורות בפורמט APA',
                required: true
              },
              {
                title: 'נספחים',
                description: 'חומרים נוספים התומכים במחקר',
                required: false
              }
            ]
          },
          {
            id: '2',
            name: 'סקירת ספרות',
            type: 'literature',
            sections: [
              {
                title: 'מבוא',
                description: 'הצגת נושא הסקירה וחשיבותו',
                required: true
              },
              {
                title: 'רקע תיאורטי',
                description: 'הצגת התיאוריות המרכזיות בתחום',
                required: true
              },
              {
                title: 'מחקרים עיקריים',
                description: 'סקירה של המחקרים המרכזיים בתחום',
                required: true
              },
              {
                title: 'מגמות עכשוויות',
                description: 'תיאור המגמות העדכניות בתחום',
                required: true
              },
              {
                title: 'פערים במחקר',
                description: 'זיהוי פערים במחקר הקיים',
                required: true
              },
              {
                title: 'סיכום',
                description: 'סיכום הנקודות העיקריות מהסקירה',
                required: true
              },
              {
                title: 'ביבליוגרפיה',
                description: 'רשימת מקורות בפורמט APA',
                required: true
              }
            ]
          },
          {
            id: '3',
            name: 'הצעת מחקר',
            type: 'proposal',
            sections: [
              {
                title: 'תקציר',
                description: 'סיכום קצר של ההצעה בכ-200 מילים',
                required: true
              },
              {
                title: 'רקע ורציונל',
                description: 'הצגת הרקע לנושא המחקר והרציונל לביצועו',
                required: true
              },
              {
                title: 'סקירת ספרות',
                description: 'סקירה קצרה של הספרות הרלוונטית',
                required: true
              },
              {
                title: 'שאלות מחקר',
                description: 'הצגת שאלות המחקר והשערות',
                required: true
              },
              {
                title: 'מתודולוגיה',
                description: 'תיאור שיטת המחקר המוצעת',
                required: true
              },
              {
                title: 'לוח זמנים',
                description: 'תכנון לוח זמנים לביצוע המחקר',
                required: true
              },
              {
                title: 'תקציב',
                description: 'פירוט התקציב הנדרש למחקר',
                required: false
              },
              {
                title: 'ביבליוגרפיה',
                description: 'רשימת מקורות בפורמט APA',
                required: true
              }
            ]
          }
        ];
        
        setTemplates(demoTemplates);
      } catch (error) {
        console.error('שגיאה בטעינת תבניות:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchTemplates();
  }, []);

  useEffect(() => {
    // Initialize content when template changes
    if (selectedTemplate) {
      const template = templates.find(t => t.id === selectedTemplate);
      if (template) {
        const initialContent: Record<string, string> = {};
        template.sections.forEach(section => {
          initialContent[section.title] = '';
        });
        setContent(initialContent);
        setFeedback({});
      }
    }
  }, [selectedTemplate, templates]);

  const handleContentChange = (section: string, value: string) => {
    setContent(prev => ({
      ...prev,
      [section]: value
    }));
  };

  const checkContent = () => {
    const template = templates.find(t => t.id === selectedTemplate);
    if (!template) return;

    const newFeedback: Record<string, string[]> = {};
    
    template.sections.forEach(section => {
      const sectionContent = content[section.title] || '';
      const issues: string[] = [];
      
      if (section.required && sectionContent.trim().length === 0) {
        issues.push('סעיף חובה - יש למלא תוכן');
      } else if (sectionContent.trim().length > 0) {
        // Simple content checks
        if (sectionContent.length < 50 && section.title !== 'תקציר') {
          issues.push('תוכן קצר מדי - מומלץ להרחיב');
        }
        
        if (sectionContent.split(' ').length < 10) {
          issues.push('מספר מילים נמוך - מומלץ להרחיב');
        }
        
        // Check for academic language
        const nonAcademicTerms = ['מגניב', 'סבבה', 'וואלה', 'בקיצור'];
        for (const term of nonAcademicTerms) {
          if (sectionContent.toLowerCase().includes(term)) {
            issues.push('נמצאו ביטויים לא אקדמיים - מומלץ להשתמש בשפה אקדמית');
            break;
          }
        }
      }
      
      if (issues.length > 0) {
        newFeedback[section.title] = issues;
      }
    });
    
    setFeedback(newFeedback);
    setActiveTab('feedback');
  };

  const getSelectedTemplate = () => {
    return templates.find(t => t.id === selectedTemplate);
  };

  const hasFeedback = (section: string) => {
    return feedback[section] && feedback[section].length > 0;
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">כלי כתיבה אקדמית</h2>
        <div className="flex space-x-2 rtl:space-x-reverse">
          <Button variant="outline" onClick={checkContent}>
            <Check className="h-4 w-4 mr-2" />
            בדיקת תוכן
          </Button>
          <Button variant="default">
            <Save className="h-4 w-4 mr-2" />
            שמירה
          </Button>
        </div>
      </div>

      <div className="flex space-x-4 rtl:space-x-reverse">
        <div className="w-1/4">
          <Card>
            <CardHeader>
              <CardTitle>בחירת תבנית</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div>טוען תבניות...</div>
              ) : (
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger>
                    <SelectValue placeholder="בחר תבנית" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map(template => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              {selectedTemplate && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">סעיפים:</h4>
                  <ul className="space-y-1 text-sm">
                    {getSelectedTemplate()?.sections.map(section => (
                      <li 
                        key={section.title} 
                        className={`cursor-pointer p-1 rounded ${
                          hasFeedback(section.title) ? 'bg-red-50 text-red-800' : ''
                        }`}
                        onClick={() => setActiveTab('editor')}
                      >
                        {section.title}
                        {section.required && <span className="text-red-500 ml-1">*</span>}
                        {hasFeedback(section.title) && (
                          <AlertCircle className="inline h-3 w-3 ml-1 text-red-500" />
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          {selectedTemplate ? (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="editor">עורך</TabsTrigger>
                <TabsTrigger value="feedback">משוב</TabsTrigger>
              </TabsList>
              
              <TabsContent value="editor" className="mt-4">
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>עריכת תוכן</CardTitle>
                        <p className="text-sm text-muted-foreground">
                          {getSelectedTemplate()?.name}
                        </p>
                      </div>
                      <Select defaultValue="section1">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="בחר סעיף" />
                        </SelectTrigger>
                        <SelectContent>
                          {getSelectedTemplate()?.sections.map((section, index) => (
                            <SelectItem key={section.title} value={`section${index + 1}`}>
                              {section.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {getSelectedTemplate()?.sections.map(section => (
                        <div key={section.title} className="space-y-2">
                          <div className="flex justify-between">
                            <label className="text-sm font-medium">
                              {section.title}
                              {section.required && <span className="text-red-500 ml-1">*</span>}
                            </label>
                            {hasFeedback(section.title) && (
                              <span className="text-sm text-red-500 flex items-center">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                יש הערות
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">{section.description}</p>
                          <Textarea
                            placeholder={`הזן תוכן עבור ${section.title}...`}
                            className="min-h-[150px]"
                            value={content[section.title] || ''}
                            onChange={(e) => handleContentChange(section.title, e.target.value)}
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="feedback" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>משוב על העבודה</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {Object.keys(feedback).length > 0 ? (
                      <div className="space-y-4">
                        {Object.entries(feedback).map(([section, issues]) => (
                          <div key={section} className="border rounded-md p-4 bg-red-50">
                            <h4 className="font-medium text-red-800">{section}</h4>
                            <ul className="mt-2 space-y-1 text-sm text-red-700">
                              {issues.map((issue, index) => (
                                <li key={index} className="flex items-start">
                                  <AlertCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                                  <span>{issue}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <FileText className="h-12 w-12 mx-auto text-green-500 mb-2" />
                        <h3 className="text-lg font-medium text-green-700">מצוין!</h3>
                        <p className="text-muted-foreground">
                          לא נמצאו בעיות בתוכן שלך. המשך בכתיבה או שמור את העבודה.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">בחר תבנית להתחלת הכתיבה</h3>
                <p className="text-muted-foreground mb-4">
                  בחר תבנית מהרשימה כדי להתחיל לכתוב את העבודה האקדמית שלך
                </p>
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger className="w-[250px] mx-auto">
                    <SelectValue placeholder="בחר תבנית" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map(template => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default WritingTool;
