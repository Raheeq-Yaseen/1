import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Search, Filter } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';

interface Summary {
  id: string;
  title: string;
  course: string;
  author: string;
  uploadDate: string;
  rating: number;
  downloads: number;
  approved: boolean;
  fileUrl: string;
}

const SummaryLibrary: React.FC = () => {
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    // Simulate API call to fetch summaries
    const fetchSummaries = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        const demoSummaries: Summary[] = [
          {
            id: '1',
            title: 'סיכום מבוא לאלגוריתמים',
            course: 'מבוא לאלגוריתמים',
            author: 'דניאל לוי',
            uploadDate: '2025-05-15',
            rating: 4.8,
            downloads: 245,
            approved: true,
            fileUrl: '/summaries/intro-algorithms.pdf'
          },
          {
            id: '2',
            title: 'סיכום מבני נתונים - עצים ומבני נתונים מתקדמים',
            course: 'מבני נתונים',
            author: 'רונית כהן',
            uploadDate: '2025-05-10',
            rating: 4.5,
            downloads: 187,
            approved: true,
            fileUrl: '/summaries/data-structures.pdf'
          },
          {
            id: '3',
            title: 'סיכום מקיף - מבוא לכלכלה',
            course: 'מבוא לכלכלה',
            author: 'אלון ישראלי',
            uploadDate: '2025-05-08',
            rating: 4.9,
            downloads: 312,
            approved: true,
            fileUrl: '/summaries/intro-economics.pdf'
          },
          {
            id: '4',
            title: 'סיכום פיזיקה 1 - מכניקה',
            course: 'פיזיקה 1',
            author: 'מיכל שרון',
            uploadDate: '2025-05-05',
            rating: 4.7,
            downloads: 198,
            approved: true,
            fileUrl: '/summaries/physics-mechanics.pdf'
          },
          {
            id: '5',
            title: 'סיכום מבוא לסטטיסטיקה',
            course: 'סטטיסטיקה',
            author: 'יוסי אברהם',
            uploadDate: '2025-05-01',
            rating: 4.6,
            downloads: 156,
            approved: true,
            fileUrl: '/summaries/statistics-intro.pdf'
          }
        ];
        
        setSummaries(demoSummaries);
      } catch (error) {
        console.error('שגיאה בטעינת סיכומים:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchSummaries();
  }, []);

  const filteredSummaries = summaries.filter(summary => {
    const matchesSearch = 
      summary.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      summary.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
      summary.author.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (activeTab === 'all') return matchesSearch;
    if (activeTab === 'popular') return matchesSearch && summary.downloads > 200;
    if (activeTab === 'recent') {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      return matchesSearch && new Date(summary.uploadDate) >= oneWeekAgo;
    }
    return matchesSearch;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('he-IL');
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`} className="text-yellow-500">★</span>);
    }
    
    if (hasHalfStar) {
      stars.push(<span key="half" className="text-yellow-500">★</span>);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="text-gray-300">★</span>);
    }
    
    return <div className="flex">{stars}</div>;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 rtl:space-x-reverse">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="חיפוש לפי קורס, מחבר או כותרת..."
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline">
          <Filter className="h-4 w-4 mr-2" />
          סינון מתקדם
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">כל הסיכומים</TabsTrigger>
          <TabsTrigger value="popular">פופולריים</TabsTrigger>
          <TabsTrigger value="recent">חדשים</TabsTrigger>
        </TabsList>
      </Tabs>

      {loading ? (
        <div className="text-center py-8">טוען סיכומים...</div>
      ) : filteredSummaries.length > 0 ? (
        <div className="grid gap-4">
          {filteredSummaries.map((summary) => (
            <Card key={summary.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{summary.title}</CardTitle>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{summary.course}</span>
                  <span>מאת: {summary.author}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    {renderStars(summary.rating)}
                    <span className="ml-1 text-sm">({summary.rating})</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {summary.downloads} הורדות | עודכן: {formatDate(summary.uploadDate)}
                  </div>
                </div>
                <div className="flex space-x-2 rtl:space-x-reverse">
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => window.open(summary.fileUrl, '_blank')}
                  >
                    הורדה
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                  >
                    צפייה מקדימה
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          לא נמצאו סיכומים התואמים את החיפוש
        </div>
      )}
    </div>
  );
};

export default SummaryLibrary;
