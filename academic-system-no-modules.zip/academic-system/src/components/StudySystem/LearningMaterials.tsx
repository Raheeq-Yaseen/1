import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Search } from 'lucide-react';

interface Material {
  id: string;
  title: string;
  type: string;
  subject: string;
  description: string;
  url: string;
}

const LearningMaterials: React.FC = () => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call to fetch learning materials
    const fetchMaterials = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        const demoMaterials: Material[] = [
          {
            id: '1',
            title: 'מבוא לאלגברה לינארית',
            type: 'מצגת',
            subject: 'מתמטיקה',
            description: 'מצגת מקיפה על יסודות האלגברה הלינארית',
            url: '/materials/linear-algebra-intro.pdf'
          },
          {
            id: '2',
            title: 'יסודות התכנות בשפת Python',
            type: 'מאמר',
            subject: 'מדעי המחשב',
            description: 'מדריך מקיף ללימוד יסודות התכנות בשפת Python',
            url: '/materials/python-basics.html'
          },
          {
            id: '3',
            title: 'מבוא לכלכלה מיקרו',
            type: 'וידאו',
            subject: 'כלכלה',
            description: 'הרצאה מוקלטת על יסודות הכלכלה המיקרו',
            url: '/materials/micro-economics.mp4'
          },
          {
            id: '4',
            title: 'תרגול פיזיקה - חוקי ניוטון',
            type: 'תרגול',
            subject: 'פיזיקה',
            description: 'דפי תרגול בנושא חוקי ניוטון עם פתרונות מלאים',
            url: '/materials/newton-laws-exercises.pdf'
          },
          {
            id: '5',
            title: 'מבוא לפסיכולוגיה קוגניטיבית',
            type: 'מאמר',
            subject: 'פסיכולוגיה',
            description: 'סקירה מקיפה של תחום הפסיכולוגיה הקוגניטיבית',
            url: '/materials/cognitive-psychology.pdf'
          }
        ];
        
        setMaterials(demoMaterials);
      } catch (error) {
        console.error('שגיאה בטעינת חומרי לימוד:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchMaterials();
  }, []);

  const filteredMaterials = materials.filter(material => 
    material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 rtl:space-x-reverse">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="חיפוש לפי נושא, סוג או כותרת..."
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline">סינון</Button>
      </div>

      {loading ? (
        <div className="text-center py-8">טוען חומרי לימוד...</div>
      ) : filteredMaterials.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredMaterials.map((material) => (
            <Card key={material.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{material.title}</CardTitle>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{material.subject}</span>
                  <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                    {material.type}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm mb-4">{material.description}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.open(material.url, '_blank')}
                >
                  צפייה בחומר
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          לא נמצאו חומרי לימוד התואמים את החיפוש
        </div>
      )}
    </div>
  );
};

export default LearningMaterials;
