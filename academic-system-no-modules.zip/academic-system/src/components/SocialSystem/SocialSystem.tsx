import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Search, Filter, MessageSquare, UserPlus } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar';
import { Badge } from '../../components/ui/badge';

interface User {
  id: string;
  name: string;
  institution: string;
  avatar: string;
  skills: string[];
  needs: string[];
  rating: number;
  ratingCount: number;
}

const SocialSystem: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    // Simulate API call to fetch users
    const fetchUsers = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        const demoUsers: User[] = [
          {
            id: '1',
            name: 'דניאל לוי',
            institution: 'אוניברסיטת תל אביב',
            avatar: '/avatars/daniel.jpg',
            skills: ['אלגוריתמים', 'מבני נתונים', 'Python'],
            needs: ['מסדי נתונים', 'רשתות תקשורת'],
            rating: 4.8,
            ratingCount: 15
          },
          {
            id: '2',
            name: 'מיכל כהן',
            institution: 'הטכניון',
            avatar: '/avatars/michal.jpg',
            skills: ['סטטיסטיקה', 'R', 'ניתוח נתונים'],
            needs: ['למידת מכונה', 'בינה מלאכותית'],
            rating: 4.9,
            ratingCount: 22
          },
          {
            id: '3',
            name: 'אמיר גולן',
            institution: 'אוניברסיטת בן גוריון',
            avatar: '/avatars/amir.jpg',
            skills: ['פיזיקה', 'מתמטיקה', 'תכנות מדעי'],
            needs: ['אלקטרוניקה', 'מערכות משובצות'],
            rating: 4.7,
            ratingCount: 9
          },
          {
            id: '4',
            name: 'שירה אברהם',
            institution: 'האוניברסיטה העברית',
            avatar: '/avatars/shira.jpg',
            skills: ['פסיכולוגיה', 'מחקר איכותני', 'SPSS'],
            needs: ['סטטיסטיקה מתקדמת', 'עיבוד נתונים'],
            rating: 4.6,
            ratingCount: 12
          },
          {
            id: '5',
            name: 'יוסי מזרחי',
            institution: 'אוניברסיטת בר אילן',
            avatar: '/avatars/yossi.jpg',
            skills: ['כלכלה', 'אקונומטריקה', 'Excel מתקדם'],
            needs: ['תכנות ב-Python', 'ויזואליזציה של נתונים'],
            rating: 4.5,
            ratingCount: 8
          }
        ];
        
        setUsers(demoUsers);
      } catch (error) {
        console.error('שגיאה בטעינת משתמשים:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchUsers();
  }, []);

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.institution.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      user.needs.some(need => need.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (activeTab === 'all') return matchesSearch;
    if (activeTab === 'skills') return matchesSearch && user.skills.length > 0;
    if (activeTab === 'needs') return matchesSearch && user.needs.length > 0;
    return matchesSearch;
  });

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`} className="text-yellow-500">★</span>);
    }
    
    if (hasHalfStar) {
      stars.push(<span key="half" className="text-yellow-500">★</span>);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="text-gray-300">★</span>);
    }
    
    return <div className="flex">{stars}</div>;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 rtl:space-x-reverse">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="חיפוש לפי שם, מוסד לימודים, כישורים או צרכים..."
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline">
          <Filter className="h-4 w-4 mr-2" />
          סינון מתקדם
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">הכל</TabsTrigger>
          <TabsTrigger value="skills">לפי כישורים</TabsTrigger>
          <TabsTrigger value="needs">לפי צרכים</TabsTrigger>
        </TabsList>
      </Tabs>

      {loading ? (
        <div className="text-center py-8">טוען משתמשים...</div>
      ) : filteredUsers.length > 0 ? (
        <div className="grid gap-4">
          {filteredUsers.map((user) => (
            <Card key={user.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4 rtl:space-x-reverse">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="text-lg font-medium">{user.name}</h3>
                        <p className="text-sm text-muted-foreground">{user.institution}</p>
                      </div>
                      <div className="flex items-center">
                        {renderStars(user.rating)}
                        <span className="ml-1 text-sm">({user.ratingCount})</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 space-y-2">
                      <div>
                        <p className="text-sm font-medium mb-1">כישורים:</p>
                        <div className="flex flex-wrap gap-1">
                          {user.skills.map(skill => (
                            <Badge key={skill} variant="secondary">{skill}</Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium mb-1">מחפש עזרה ב:</p>
                        <div className="flex flex-wrap gap-1">
                          {user.needs.map(need => (
                            <Badge key={need} variant="outline">{need}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex space-x-2 rtl:space-x-reverse">
                      <Button variant="default" size="sm" className="flex-1">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        שלח הודעה
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <UserPlus className="h-4 w-4 mr-2" />
                        הוסף לרשימת קשר
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          לא נמצאו משתמשים התואמים את החיפוש
        </div>
      )}
    </div>
  );
};

export default SocialSystem;
