import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Search, Calendar, CheckCircle, Clock } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { Badge } from '../../components/ui/badge';

interface Task {
  id: string;
  title: string;
  course: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in-progress' | 'completed';
  description: string;
}

const TaskManager: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    // Simulate API call to fetch tasks
    const fetchTasks = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        const demoTasks: Task[] = [
          {
            id: '1',
            title: 'הגשת עבודה באלגוריתמים',
            course: 'מבוא לאלגוריתמים',
            dueDate: '2025-06-15',
            priority: 'high',
            status: 'in-progress',
            description: 'יש להגיש עבודה על מיון וחיפוש, כולל ניתוח סיבוכיות'
          },
          {
            id: '2',
            title: 'מצגת לקורס תקשורת',
            course: 'תקשורת מחשבים',
            dueDate: '2025-06-20',
            priority: 'medium',
            status: 'pending',
            description: 'הכנת מצגת על פרוטוקולי אבטחה בתקשורת'
          },
          {
            id: '3',
            title: 'תרגיל בית במתמטיקה',
            course: 'אלגברה לינארית',
            dueDate: '2025-06-10',
            priority: 'high',
            status: 'pending',
            description: 'תרגילים 5-10 בנושא מטריצות ודטרמיננטות'
          },
          {
            id: '4',
            title: 'קריאת מאמר',
            course: 'פסיכולוגיה חברתית',
            dueDate: '2025-06-25',
            priority: 'low',
            status: 'pending',
            description: 'קריאת מאמר "השפעת הרשתות החברתיות על התנהגות חברתית"'
          },
          {
            id: '5',
            title: 'הכנה למבחן אמצע',
            course: 'סטטיסטיקה',
            dueDate: '2025-06-18',
            priority: 'high',
            status: 'in-progress',
            description: 'חזרה על פרקים 1-5, כולל תרגול מבחנים משנים קודמות'
          }
        ];
        
        setTasks(demoTasks);
      } catch (error) {
        console.error('שגיאה בטעינת משימות:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchTasks();
  }, []);

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = 
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (activeTab === 'all') return matchesSearch;
    if (activeTab === 'pending') return matchesSearch && task.status === 'pending';
    if (activeTab === 'in-progress') return matchesSearch && task.status === 'in-progress';
    if (activeTab === 'completed') return matchesSearch && task.status === 'completed';
    return matchesSearch;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('he-IL');
  };

  const getDaysRemaining = (dateString: string) => {
    const dueDate = new Date(dateString);
    const today = new Date();
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 mr-1" />;
      case 'in-progress': return <Clock className="h-4 w-4 mr-1" />;
      case 'pending': return <Calendar className="h-4 w-4 mr-1" />;
      default: return null;
    }
  };

  const handleStatusChange = (taskId: string, newStatus: 'pending' | 'in-progress' | 'completed') => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 rtl:space-x-reverse">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="חיפוש לפי קורס או כותרת..."
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="default">משימה חדשה</Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">הכל</TabsTrigger>
          <TabsTrigger value="pending">ממתינות</TabsTrigger>
          <TabsTrigger value="in-progress">בתהליך</TabsTrigger>
          <TabsTrigger value="completed">הושלמו</TabsTrigger>
        </TabsList>
      </Tabs>

      {loading ? (
        <div className="text-center py-8">טוען משימות...</div>
      ) : filteredTasks.length > 0 ? (
        <div className="grid gap-4">
          {filteredTasks.map((task) => {
            const daysRemaining = getDaysRemaining(task.dueDate);
            
            return (
              <Card key={task.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{task.title}</CardTitle>
                    <div className="flex space-x-2 rtl:space-x-reverse">
                      <Badge className={getPriorityColor(task.priority)}>
                        {task.priority === 'high' ? 'גבוהה' : task.priority === 'medium' ? 'בינונית' : 'נמוכה'}
                      </Badge>
                      <Badge className={getStatusColor(task.status)}>
                        <span className="flex items-center">
                          {getStatusIcon(task.status)}
                          {task.status === 'completed' ? 'הושלם' : task.status === 'in-progress' ? 'בתהליך' : 'ממתין'}
                        </span>
                      </Badge>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {task.course} | תאריך יעד: {formatDate(task.dueDate)}
                    {task.status !== 'completed' && (
                      <span className={`ml-2 ${daysRemaining < 3 ? 'text-red-500 font-bold' : ''}`}>
                        {daysRemaining > 0 ? `${daysRemaining} ימים נותרו` : 'עבר התאריך!'}
                      </span>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4">{task.description}</p>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    {task.status !== 'completed' && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => handleStatusChange(task.id, 'completed')}
                      >
                        סמן כהושלם
                      </Button>
                    )}
                    {task.status !== 'in-progress' && task.status !== 'completed' && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => handleStatusChange(task.id, 'in-progress')}
                      >
                        התחל עבודה
                      </Button>
                    )}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                    >
                      ערוך
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-8">
          לא נמצאו משימות התואמות את החיפוש
        </div>
      )}
    </div>
  );
};

export default TaskManager;
