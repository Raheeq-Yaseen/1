import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import LearningMaterials from '../components/StudySystem/LearningMaterials';
import SummaryLibrary from '../components/SummaryLibrary/SummaryLibrary';
import TaskManager from '../components/TaskManager/TaskManager';
import WritingTool from '../components/WritingTool/WritingTool';
import SocialSystem from '../components/SocialSystem/SocialSystem';

const HomePage: React.FC = () => {
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">מערכת אקדמית משולבת לסטודנטים</h1>
        <p className="text-muted-foreground">
          פלטפורמה מקיפה לניהול הלימודים, סיכומים, משימות, כתיבה אקדמית וקשרים חברתיים
        </p>
      </div>

      <Tabs defaultValue="study" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="study">מערכת למידה</TabsTrigger>
          <TabsTrigger value="summaries">ספריית סיכומים</TabsTrigger>
          <TabsTrigger value="tasks">ניהול משימות</TabsTrigger>
          <TabsTrigger value="writing">כלי כתיבה</TabsTrigger>
          <TabsTrigger value="social">מערכת חברתית</TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="study">
            <LearningMaterials />
          </TabsContent>
          
          <TabsContent value="summaries">
            <SummaryLibrary />
          </TabsContent>
          
          <TabsContent value="tasks">
            <TaskManager />
          </TabsContent>
          
          <TabsContent value="writing">
            <WritingTool />
          </TabsContent>
          
          <TabsContent value="social">
            <SocialSystem />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default HomePage;
